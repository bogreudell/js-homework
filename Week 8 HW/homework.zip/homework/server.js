var http = require('http'),
	fs = require('fs')

var languages = [
	{
		name: 'basque'
		//family: 'language isolate'
		//politicalStatus1: 'regionally official'
		//country: 'spain'
	}
	/*{
		name: 'catalan'
		// family: 'indo-european'
		//politicalStatus1: 'regionally official'
		//politicalStatus2: 'nationally official'
		//country1: 'spain'
		//country2: 'andorra'
	}*/
]
 
var server = http.createServer(function (request, response) {

	if (request.url === '/') {
		
		fs.readFile('index.html', 'utf-8', function (err, file) {
        	
        file = file
        			.replace('{{name}}','Basque')

        response.end(file)

        })
	
	} else if (request.url === '/languages') {

		response.end(JSON.stringify(languages))

	} else {

		response.end('404')

	}
 
})

server.listen(8888)